function dummy() {
    console.log('dummy');
    console.log(dijit.byId("sizeCols").get('value'));
}

/*
$(document.getElementById('chartHolder')).on('mousedown', function (evt) {
    mouse.DnOrganPos=[evt.offsetX, evt.offsetY];
    mouse.Dn = true;
    mouse.Picked = '';
    console.log('click in chartholder');
});
*/

