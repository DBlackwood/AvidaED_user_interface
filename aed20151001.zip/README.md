# av_ui
avida_ed user interface initially directly as created using Maqetta

Ignore the subfolder avida_ui. We are using avida_ui2
the file app.js is also not in use. however app.css is in use. 
