//>>built
define("dojox/main",["dojo/_base/kernel"],function(_1){
return _1.dojox;
});
