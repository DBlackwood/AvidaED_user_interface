//>>built
define("dojox/drawing",["./drawing/_base"],function(){
});
