//>>built
define("dojox/drawing/_base",["dojo","./annotations/Label","./Drawing"],function(_1,L,_2){
_1.experimental("dojox.drawing");
return _2;
});
