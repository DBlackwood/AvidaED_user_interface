//>>built
define("dojox/wire",["./wire/_base"],function(){
});
