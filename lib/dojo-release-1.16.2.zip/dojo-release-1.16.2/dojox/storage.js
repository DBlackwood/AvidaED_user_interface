//>>built
define("dojox/storage",["./storage/_common"],function(){
});
