//>>built
define("dojox/form/DropDownSelect",["dojo/_base/kernel","dojo/_base/lang","dijit/form/Select"],function(_1,_2,_3){
_1.deprecated("dojox.form.DropDownSelect","Use Select instead","2.0");
_2.setObject("dojox.form.DropDownSelect",_3);
return _3;
});
