//>>built
define("dojox/form/BusyComboButton",["./_BusyButtonMixin","dijit/form/ComboButton","dojo/_base/declare"],function(_1,_2,_3){
return _3("dojox.form.BusyComboButton",[_2,_1],{});
});
