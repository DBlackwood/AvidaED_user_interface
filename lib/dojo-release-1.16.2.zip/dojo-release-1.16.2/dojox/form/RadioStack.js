//>>built
define("dojox/form/RadioStack",["./CheckedMultiSelect","./_SelectStackMixin","dojo/_base/declare"],function(_1,_2,_3){
return _3("dojox.form.RadioStack",[_1,_2]);
});
