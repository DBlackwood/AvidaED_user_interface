//>>built
define("dojox/form/BusyDropDownButton",["./_BusyButtonMixin","dijit/form/DropDownButton","dojo/_base/declare"],function(_1,_2,_3){
return _3("dojox.form.BusyDropDownButton",[_2,_1],{});
});
