//>>built
define("dojox/form/FileInputBlind",["dojo/_base/lang","dojox/form/FileInputAuto"],function(_1,_2){
_1.setObject("dojox.form.FileInputBlind",_2);
return _2;
});
