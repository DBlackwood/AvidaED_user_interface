//>>built
define("dojox/form/BusyButton",["./_BusyButtonMixin","dijit/form/Button","dojo/_base/declare"],function(_1,_2,_3){
var _4=_3("dojox.form.BusyButton",[_2,_1],{});
return _4;
});
