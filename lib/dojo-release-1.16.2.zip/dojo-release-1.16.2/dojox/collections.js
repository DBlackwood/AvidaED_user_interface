//>>built
define("dojox/collections",["./collections/_base"],function(_1){
return _1;
});
