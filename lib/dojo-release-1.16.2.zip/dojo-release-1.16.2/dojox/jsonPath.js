//>>built
define("dojox/jsonPath",["dojo/_base/kernel","./jsonPath/query"],function(_1,_2){
_1.deprecated("dojox/jsonPath: The dojox/jsonPath root module is deprecated, use dojox/jsonPath/query","","2.0");
return {query:_2};
});
