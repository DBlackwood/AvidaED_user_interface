All contributions to this repository must:
- be done under the Dojo Contributor License Agreement (CLA, http://dojofoundation.org/about/claForm) that you must sign
- follow the Dojo style guide (https://dojotoolkit.org/community/styleGuide)
