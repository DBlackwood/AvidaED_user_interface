
av.dcn.diagnosticConsoleFn = function () {
  'use strict';
  console.log('inside diagnoticConsole');
}